# 🚀 GitHub Codespaces - Quick Start Guide

## Automatisk Setup (Ferdig når du åpner Codespaces!)

Når du starter en ny Codespace, settes alt opp automatisk:
- ✅ Python-pakker installeres
- ✅ Database opprettes
- ✅ Eksempeldata legges inn
- ✅ VS Code extensions installeres

## Start Appen

### Metode 1: Enkel kommando
```bash
streamlit run app.py
```

### Metode 2: Bruk oppstartsskriptet
```bash
./start_codespaces.sh
```

## Første Gang i Appen

1. **Appen åpnes automatisk** i en ny fane
2. Hvis ikke, gå til **"Ports"-fanen** nederst og klikk på **port 8501**
3. I appen:
   - Klikk **"🔄 Last inn Oslo Børs aksjer"** i sidemenyen
   - Klikk **"📊 Oppdater alle markedsdata"**

## Nyttige Kommandoer

```bash
# Test yfinance-tilkobling
python test_yfinance.py

# Oppdater alle Oslo Børs-data
python update_oslo_bors.py

# Reinitialiser database
python db_init.py --with-samples

# Se topp utbytteaksjer
python update_oslo_bors.py
# Velg option 2
```

## Tips for Codespaces

1. **Ports**: Streamlit kjører på port 8501
2. **Auto-save**: Endringer lagres automatisk
3. **Extensions**: Python, Pylance og GitHub Copilot er forhåndsinstallert
4. **Terminal**: Bruk den integrerte terminalen i VS Code
5. **Syncing**: Endringer synkroniseres automatisk til GitHub

## Problemer?

- **Appen starter ikke?** Sjekk "Ports"-fanen og åpne port 8501 manuelt
- **Database-feil?** Kjør: `python db_init.py`
- **Manglende pakker?** Kjør: `pip install -r requirements.txt`

## Ressurser

- 📚 [Full dokumentasjon](README.md)
- 🐛 [Rapporter problemer](https://github.com/your-repo/issues)
- 💡 [GitHub Codespaces Docs](https://docs.github.com/en/codespaces)

---
**Lykke til med din Oslo Børs-portefølje! 🇳🇴**
