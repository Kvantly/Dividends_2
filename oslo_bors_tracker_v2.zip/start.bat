@echo off
echo ========================================
echo  Oslo Bors Portfolio Tracker
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python from https://www.python.org/
    pause
    exit /b 1
)

REM Check if virtual environment exists
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install/update requirements
echo Installing requirements...
pip install -r requirements.txt

REM Check if database exists
if not exist "data.db" (
    echo Initializing database...
    python db_init.py
)

REM Start the application
echo.
echo =====================================
echo Starting Streamlit application...
echo Open your browser at: http://localhost:8501
echo Press Ctrl+C to stop the application
echo =====================================
echo.

streamlit run app.py

pause
