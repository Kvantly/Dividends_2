# 🚀 GitHub Setup - Steg for Steg

## 1️⃣ Opprett nytt GitHub Repository

1. Gå til [github.com/new](https://github.com/new)
2. Gi repositoriet et navn (f.eks. `oslo-bors-tracker`)
3. Velg **Public** eller **Private**
4. **IKKE** initialiser med README, .gitignore eller license
5. Klikk **Create repository**

## 2️⃣ Last opp filene

### Alternativ A: Via GitHub Web UI
1. Klikk **"uploading an existing file"** i det nye repositoriet
2. Dra og slipp alle filene fra zip-filen
3. Skriv commit-melding: "Initial commit - Oslo Børs Portfolio Tracker"
4. Klikk **Commit changes**

### Alternativ B: Via Git kommandolinje
```bash
# Pakk ut zip-filen først
unzip oslo_bors_tracker_codespaces.zip -d oslo-bors-tracker
cd oslo-bors-tracker

# Initialiser git og push til GitHub
git init
git add .
git commit -m "Initial commit - Oslo Børs Portfolio Tracker"
git branch -M main
git remote add origin https://github.com/DITT_BRUKERNAVN/oslo-bors-tracker.git
git push -u origin main
```

## 3️⃣ Start GitHub Codespaces

1. Gå til ditt nye repository på GitHub
2. Klikk den grønne **"Code"**-knappen
3. Velg **"Codespaces"**-fanen
4. Klikk **"Create codespace on main"**
5. Vent 1-2 minutter mens alt settes opp automatisk

## 4️⃣ Kjør appen i Codespaces

Når Codespaces er klar:

```bash
# Appen er allerede klar! Bare kjør:
streamlit run app.py

# Eller bruk det custom scriptet:
./start_codespaces.sh
```

## 5️⃣ Aktiver GitHub Actions (Valgfritt)

1. Gå til **Settings** → **Actions** → **General**
2. Under "Actions permissions", velg **"Allow all actions"**
3. Klikk **Save**

Dette aktiverer:
- Automatisk testing av koden
- Daglig oppdatering av markedsdata

## 📱 Dele appen med andre

### Gjør Codespace public:
1. Gå til **Settings** i Codespaces (tannhjul-ikon)
2. Under **"Port visibility"** for port 8501
3. Velg **"Public"**
4. Del URL-en med andre!

## 🔧 Tilpasninger

### Endre tema/farger:
Rediger `.streamlit/config.toml`

### Legge til flere aksjer:
Rediger `oslo_bors_tickers.csv`

### Endre database:
Kjør `python db_init.py` på nytt

## ❓ Hjelp

- **Problem med Codespaces?** Sjekk [GitHub Codespaces docs](https://docs.github.com/codespaces)
- **Problem med appen?** Se `CODESPACES_GUIDE.md`
- **Generelle spørsmål?** Les `README.md`

## 🎉 Ferdig!

Du har nå din egen Oslo Børs Portfolio Tracker kjørende i skyen!
Ingen lokal installasjon nødvendig - alt kjører i GitHub Codespaces.

---

**Tips:** Legg til en ⭐ på repositoriet hvis du liker prosjektet!
