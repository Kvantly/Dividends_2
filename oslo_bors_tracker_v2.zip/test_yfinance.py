#!/usr/bin/env python3
"""
Test script to verify yfinance connectivity with Oslo Børs stocks
"""

import yfinance as yf
from datetime import datetime, timedelta
import sys

def test_ticker(ticker_symbol):
    """
    Test a single ticker and display results
    """
    print(f"\n{'='*50}")
    print(f"Testing: {ticker_symbol}")
    print('='*50)
    
    try:
        ticker = yf.Ticker(ticker_symbol)
        
        # Test 1: Get basic info
        print("\n1. BASIC INFO:")
        info = ticker.info
        if info:
            print(f"   ✅ Company: {info.get('longName', 'N/A')}")
            print(f"   ✅ Sector: {info.get('sector', 'N/A')}")
            print(f"   ✅ Currency: {info.get('currency', 'N/A')}")
            print(f"   ✅ Exchange: {info.get('exchange', 'N/A')}")
        else:
            print("   ❌ Could not retrieve basic info")
        
        # Test 2: Get recent price history
        print("\n2. PRICE HISTORY (Last 5 days):")
        hist = ticker.history(period="5d")
        if not hist.empty:
            for date, row in hist.tail().iterrows():
                print(f"   {date.strftime('%Y-%m-%d')}: {row['Close']:.2f} NOK")
            print(f"   ✅ Latest price: {hist['Close'].iloc[-1]:.2f} NOK")
        else:
            print("   ❌ No price history available")
        
        # Test 3: Get dividends
        print("\n3. DIVIDEND HISTORY (Last 5 dividends):")
        dividends = ticker.dividends
        if not dividends.empty:
            for date, amount in dividends.tail().items():
                print(f"   {date.strftime('%Y-%m-%d')}: {amount:.2f} NOK")
            
            # Calculate yield
            if not hist.empty:
                last_price = hist['Close'].iloc[-1]
                one_year_ago = datetime.now() - timedelta(days=365)
                recent_divs = dividends[dividends.index >= one_year_ago]
                if not recent_divs.empty:
                    annual_dividend = recent_divs.sum()
                    dividend_yield = (annual_dividend / last_price) * 100
                    print(f"   ✅ Annual dividend: {annual_dividend:.2f} NOK")
                    print(f"   ✅ Dividend yield: {dividend_yield:.2f}%")
        else:
            print("   ℹ️  No dividend history available")
        
        # Test 4: Get upcoming events
        print("\n4. UPCOMING EVENTS:")
        calendar = ticker.calendar
        if calendar:
            if 'Earnings Date' in calendar:
                print(f"   📅 Next earnings: {calendar['Earnings Date']}")
            if 'Ex-Dividend Date' in calendar:
                print(f"   💰 Ex-dividend date: {calendar['Ex-Dividend Date']}")
            if 'Dividend Date' in calendar:
                print(f"   💰 Dividend payment: {calendar['Dividend Date']}")
        else:
            print("   ℹ️  No upcoming events")
        
        print(f"\n✅ {ticker_symbol} test completed successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Error testing {ticker_symbol}: {e}")
        return False

def main():
    """
    Main test function
    """
    print("=" * 60)
    print(" YFINANCE OSLO BØRS CONNECTIVITY TEST")
    print("=" * 60)
    
    # Test tickers - mix of large, medium and small cap
    test_tickers = [
        "EQNR.OL",  # Equinor - Large cap energy
        "DNB.OL",   # DNB - Large cap bank
        "MOWI.OL",  # Mowi - Large cap seafood
        "NEL.OL",   # Nel - Medium cap hydrogen
        "KAHOT.OL", # Kahoot - Tech/education
    ]
    
    # Allow custom ticker as argument
    if len(sys.argv) > 1:
        test_tickers = [sys.argv[1]]
        print(f"\nTesting custom ticker: {test_tickers[0]}")
    else:
        print(f"\nTesting {len(test_tickers)} sample Oslo Børs tickers...")
    
    successful = 0
    failed = 0
    
    for ticker in test_tickers:
        if test_ticker(ticker):
            successful += 1
        else:
            failed += 1
    
    # Summary
    print("\n" + "=" * 60)
    print(" TEST SUMMARY")
    print("=" * 60)
    print(f"✅ Successful: {successful}/{len(test_tickers)}")
    print(f"❌ Failed: {failed}/{len(test_tickers)}")
    
    if successful == len(test_tickers):
        print("\n🎉 All tests passed! yfinance is working correctly with Oslo Børs.")
    elif successful > 0:
        print("\n⚠️  Some tests passed. Check failed tickers for issues.")
    else:
        print("\n❌ All tests failed. Check your internet connection and yfinance installation.")
    
    # Test if we can get real-time data
    print("\n" + "=" * 60)
    print(" REAL-TIME DATA TEST")
    print("=" * 60)
    
    try:
        ticker = yf.Ticker("EQNR.OL")
        info = ticker.info
        
        if 'bid' in info and info['bid']:
            print(f"✅ Real-time bid: {info['bid']} NOK")
        if 'ask' in info and info['ask']:
            print(f"✅ Real-time ask: {info['ask']} NOK")
        if 'regularMarketPrice' in info and info['regularMarketPrice']:
            print(f"✅ Market price: {info['regularMarketPrice']} NOK")
        
        market_state = info.get('marketState', 'UNKNOWN')
        print(f"\n📊 Market state: {market_state}")
        
        if market_state == "REGULAR":
            print("✅ Market is currently OPEN")
        elif market_state == "CLOSED":
            print("ℹ️  Market is currently CLOSED")
        else:
            print(f"ℹ️  Market state: {market_state}")
            
    except Exception as e:
        print(f"❌ Could not get real-time data: {e}")
    
    print("\n" + "=" * 60)
    print(" TEST COMPLETE")
    print("=" * 60)

if __name__ == "__main__":
    main()
