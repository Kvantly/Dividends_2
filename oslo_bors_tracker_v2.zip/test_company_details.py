#!/usr/bin/env python3
"""
Test script to verify the company details functionality
"""

import sqlite3
import pandas as pd
from datetime import datetime, timedelta

def test_company_details():
    """
    Test that the database structure supports company details view
    """
    print("Testing Company Details Functionality")
    print("=" * 50)
    
    try:
        # Connect to database
        conn = sqlite3.connect('data.db')
        
        # Check if we have tickers
        tickers = pd.read_sql_query("SELECT ticker, name FROM tickers LIMIT 5", conn)
        print(f"✅ Found {len(tickers)} tickers in database")
        
        if not tickers.empty:
            print("\nSample tickers:")
            for _, row in tickers.iterrows():
                print(f"  - {row['ticker']}: {row['name']}")
        
        # Check historical dividends
        hist_divs = pd.read_sql_query("""
            SELECT ticker, COUNT(*) as count, 
                   MIN(date) as first_date, 
                   MAX(date) as last_date
            FROM historical_dividends 
            GROUP BY ticker
            LIMIT 5
        """, conn)
        
        if not hist_divs.empty:
            print(f"\n✅ Found historical dividends for {len(hist_divs)} tickers")
            print("\nDividend history summary:")
            for _, row in hist_divs.iterrows():
                print(f"  - {row['ticker']}: {row['count']} dividends from {row['first_date']} to {row['last_date']}")
        else:
            print("\n⚠️  No historical dividends found. Run 'Oppdater alle markedsdata' in the app.")
        
        # Check market cache
        market_data = pd.read_sql_query("""
            SELECT ticker, last_price, last_updated 
            FROM market_cache 
            WHERE last_price IS NOT NULL
            LIMIT 5
        """, conn)
        
        if not market_data.empty:
            print(f"\n✅ Found market data for {len(market_data)} tickers")
            print("\nCurrent prices:")
            for _, row in market_data.iterrows():
                print(f"  - {row['ticker']}: {row['last_price']:.2f} NOK (updated: {row['last_updated'][:10]})")
        
        conn.close()
        print("\n✅ Company details feature is ready to use!")
        print("\nTo use it in the app:")
        print("1. Run: streamlit run app.py")
        print("2. Go to the '🏢 Selskapsdetaljer' tab")
        print("3. Select a company from the dropdown")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nMake sure to:")
        print("1. Run: python db_init.py")
        print("2. Click 'Oppdater alle markedsdata' in the app")

if __name__ == "__main__":
    test_company_details()
