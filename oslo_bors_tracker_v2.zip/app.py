import streamlit as st
import sqlite3
import pandas as pd
import yfinance as yf
import datetime
import json
from typing import Dict, List, Optional, Tuple
import time

DB = "data.db"

# Cache for yfinance data
@st.cache_data(ttl=300)  # Cache for 5 minutes
def fetch_ticker_info(ticker: str) -> Dict:
    """Hent utvidet info om en ticker"""
    try:
        tk = yf.Ticker(ticker)
        info = tk.info
        return info
    except:
        return {}

@st.cache_resource
def get_conn():
    """Get database connection"""
    return sqlite3.connect(DB, check_same_thread=False)

def init_db(conn):
    """Initialize database tables if they don't exist"""
    cur = conn.cursor()
    
    # Tickers table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS tickers (
            ticker TEXT PRIMARY KEY,
            name TEXT,
            sector TEXT,
            industry TEXT,
            market_cap REAL,
            last_updated TEXT
        )
    """)
    
    # Transactions table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            ticker TEXT NOT NULL,
            quantity REAL NOT NULL,
            price REAL NOT NULL,
            fee REAL DEFAULT 0,
            notes TEXT
        )
    """)
    
    # Received dividends table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS received_dividends (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            ticker TEXT NOT NULL,
            amount REAL NOT NULL,
            shares_held REAL,
            per_share REAL,
            notes TEXT
        )
    """)
    
    # Market cache table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS market_cache (
            ticker TEXT PRIMARY KEY,
            last_price REAL,
            last_updated TEXT,
            dividends_json TEXT,
            info_json TEXT
        )
    """)
    
    # Historical dividends table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS historical_dividends (
            ticker TEXT,
            date TEXT,
            dividend REAL,
            PRIMARY KEY (ticker, date)
        )
    """)
    
    conn.commit()

def load_tickers(conn) -> pd.DataFrame:
    """Load tickers from database"""
    try:
        df = pd.read_sql_query('SELECT * FROM tickers ORDER BY ticker', conn)
    except Exception:
        df = pd.DataFrame(columns=['ticker', 'name', 'sector', 'industry', 'market_cap'])
    return df

def upsert_ticker(conn, ticker: str, name: str = None, sector: str = None, 
                  industry: str = None, market_cap: float = None):
    """Insert or update ticker info"""
    now = datetime.datetime.utcnow().isoformat()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO tickers (ticker, name, sector, industry, market_cap, last_updated)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(ticker) DO UPDATE SET 
            name=COALESCE(excluded.name, name),
            sector=COALESCE(excluded.sector, sector),
            industry=COALESCE(excluded.industry, industry),
            market_cap=COALESCE(excluded.market_cap, market_cap),
            last_updated=excluded.last_updated
    """, (ticker, name, sector, industry, market_cap, now))
    conn.commit()

def get_oslo_bors_tickers() -> List[str]:
    """Returnerer en liste over populære Oslo Børs-aksjer"""
    # Dette er de mest handlede aksjene på Oslo Børs
    # For full liste kan du bruke web scraping eller API
    return [
        "EQNR.OL",  # Equinor
        "DNB.OL",   # DNB
        "TEL.OL",   # Telenor
        "MOWI.OL",  # Mowi
        "YAR.OL",   # Yara
        "ORK.OL",   # Orkla
        "AKRBP.OL", # Aker BP
        "NHY.OL",   # Norsk Hydro
        "SALM.OL",  # SalMar
        "SUBC.OL",  # Subsea 7
        "TGS.OL",   # TGS
        "GJFS.OL",   # Gjensidige
        "STB.OL",   # Storebrand
        "SCHR.OL",  # Schibsted
        "KOG.OL",   # Kongsberg Gruppen
        "TOM.OL",   # Tomra
        "NEL.OL",   # Nel
        "BWLPG.OL", # BW LPG
        "AKSO.OL",  # Aker Solutions
        "PGS.OL",   # PGS
        "NOD.OL",   # Nordic Semiconductor
        "ENTRA.OL", # Entra
        "RECSI.OL", # REC Silicon
        "BWO.OL",   # BW Offshore
        "AKA.OL",   # Aker
        "NONG.OL",  # SpareBank 1 Nord-Norge
        "SRBANK.OL", # SpareBank 1 SR-Bank
        "BAKKA.OL", # Bakkafrost
        "AFG.OL",   # Austevoll Seafood
        "LSG.OL",   # Lerøy Seafood
    ]

def fetch_market_data(tickers: List[str], progress_bar=None) -> Dict:
    """Hent markedsdata for flere tickers"""
    results = {}
    total = len(tickers)
    
    for idx, ticker in enumerate(tickers):
        if progress_bar:
            progress_bar.progress((idx + 1) / total, f"Henter data for {ticker}...")
        
        try:
            tk = yf.Ticker(ticker)
            
            # Hent historikk for siste pris
            hist = tk.history(period='1mo', interval='1d')
            if not hist.empty:
                price = float(hist['Close'].iloc[-1])
            else:
                price = None
            
            # Hent info
            info = tk.info
            name = info.get('longName') or info.get('shortName', ticker)
            sector = info.get('sector')
            industry = info.get('industry')
            market_cap = info.get('marketCap')
            
            # Hent utbyttehistorikk
            divs = tk.dividends
            if isinstance(divs, pd.Series) and not divs.empty:
                divs = divs.reset_index()
                divs.columns = ['date', 'dividend']
                divs['date'] = divs['date'].dt.strftime('%Y-%m-%d')
                divs_list = divs.to_dict(orient='records')
            else:
                divs_list = []
            
            # Hent neste utbytte hvis tilgjengelig
            next_div_date = info.get('exDividendDate')
            if next_div_date:
                try:
                    next_div_date = datetime.datetime.fromtimestamp(next_div_date).strftime('%Y-%m-%d')
                except:
                    next_div_date = None
            
            results[ticker] = {
                'price': price,
                'name': name,
                'sector': sector,
                'industry': industry,
                'market_cap': market_cap,
                'dividends': divs_list,
                'next_dividend_date': next_div_date,
                'info': info
            }
            
            # Litt delay for å unngå rate limiting
            time.sleep(0.1)
            
        except Exception as e:
            results[ticker] = {
                'price': None,
                'dividends': [],
                'error': str(e)
            }
    
    if progress_bar:
        progress_bar.empty()
    
    return results

def calculate_dividend_metrics(conn, ticker: str) -> Dict:
    """Beregn utbyttemetrikker for en ticker"""
    cur = conn.cursor()
    
    # Hent historiske utbytter
    cur.execute("""
        SELECT date, dividend 
        FROM historical_dividends 
        WHERE ticker = ? 
        ORDER BY date DESC
    """, (ticker,))
    
    divs = cur.fetchall()
    if not divs:
        return {}
    
    # Hent siste pris
    cur.execute("SELECT last_price FROM market_cache WHERE ticker = ?", (ticker,))
    price_row = cur.fetchone()
    if not price_row or not price_row[0]:
        return {}
    
    price = price_row[0]
    
    # Beregn metrikker
    total_last_year = 0
    one_year_ago = datetime.datetime.now() - datetime.timedelta(days=365)
    
    for date_str, dividend in divs:
        div_date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
        if div_date >= one_year_ago:
            total_last_year += dividend
    
    dividend_yield = (total_last_year / price * 100) if price > 0 else 0
    
    return {
        'total_dividends_last_year': total_last_year,
        'dividend_yield': dividend_yield,
        'last_dividend': divs[0][1] if divs else None,
        'last_dividend_date': divs[0][0] if divs else None,
        'dividend_count_last_year': len([d for d in divs if datetime.datetime.strptime(d[0], '%Y-%m-%d') >= one_year_ago])
    }

def main():
    st.set_page_config(
        page_title='Oslo Børs - Portefølje & Utbytte',
        layout='wide',
        initial_sidebar_state='expanded'
    )
    
    st.title('📈 Oslo Børs - Portefølje & Utbytte Tracker')
    
    conn = get_conn()
    init_db(conn)
    
    # Sidebar
    with st.sidebar:
        st.header('⚙️ Kontroller')
        
        if st.button('🔄 Last inn Oslo Børs aksjer', type='primary'):
            oslo_tickers = get_oslo_bors_tickers()
            for ticker in oslo_tickers:
                upsert_ticker(conn, ticker)
            st.success(f'La til {len(oslo_tickers)} Oslo Børs-aksjer')
        
        st.divider()
        
        # Legg til egendefinert ticker
        with st.expander('➕ Legg til ticker manuelt'):
            new_ticker = st.text_input('Ticker (f.eks. EQNR.OL)')
            if st.button('Legg til'):
                if new_ticker:
                    upsert_ticker(conn, new_ticker.upper())
                    st.success(f'La til {new_ticker.upper()}')
                    st.rerun()
        
        st.divider()
        
        # Oppdater markedsdata
        if st.button('📊 Oppdater alle markedsdata', type='secondary'):
            tickers_df = load_tickers(conn)
            if not tickers_df.empty:
                progress = st.progress(0, text="Starter oppdatering...")
                with st.spinner('Henter markedsdata...'):
                    results = fetch_market_data(tickers_df['ticker'].tolist(), progress)
                    
                    for ticker, data in results.items():
                        # Oppdater ticker info
                        if 'error' not in data:
                            upsert_ticker(
                                conn, ticker,
                                name=data.get('name'),
                                sector=data.get('sector'),
                                industry=data.get('industry'),
                                market_cap=data.get('market_cap')
                            )
                            
                            # Oppdater market cache
                            cur = conn.cursor()
                            cur.execute("""
                                INSERT OR REPLACE INTO market_cache 
                                (ticker, last_price, last_updated, dividends_json, info_json)
                                VALUES (?, ?, ?, ?, ?)
                            """, (
                                ticker,
                                data.get('price'),
                                datetime.datetime.utcnow().isoformat(),
                                json.dumps(data.get('dividends', [])),
                                json.dumps(data.get('info', {}))
                            ))
                            
                            # Oppdater historiske utbytter
                            for div in data.get('dividends', []):
                                cur.execute("""
                                    INSERT OR REPLACE INTO historical_dividends
                                    (ticker, date, dividend)
                                    VALUES (?, ?, ?)
                                """, (ticker, div['date'], div['dividend']))
                            
                            conn.commit()
                
                st.success('✅ Markedsdata oppdatert!')
            else:
                st.warning('Ingen tickers å oppdatere. Last inn Oslo Børs-aksjer først.')
    
    # Hovedinnhold
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(['📊 Dashboard', '💼 Transaksjoner', '💰 Utbytter', '🏢 Selskapsdetaljer', '📈 Analyse', '⚙️ Data'])
    
    with tab1:
        st.header('📊 Porteføljeoversikt')
        
        # Hent data
        tx_df = pd.read_sql_query('SELECT * FROM transactions ORDER BY date DESC', conn)
        
        if not tx_df.empty:
            # Beregn holdings
            holdings = tx_df.groupby('ticker')['quantity'].sum().reset_index()
            holdings = holdings[holdings['quantity'] > 0]  # Filtrer bort solgte posisjoner
            
            # Legg til priser og info
            prices = []
            for ticker in holdings['ticker']:
                cur = conn.cursor()
                cur.execute("""
                    SELECT last_price, last_updated 
                    FROM market_cache 
                    WHERE ticker = ?
                """, (ticker,))
                row = cur.fetchone()
                
                cur.execute("""
                    SELECT name, sector 
                    FROM tickers 
                    WHERE ticker = ?
                """, (ticker,))
                info_row = cur.fetchone()
                
                prices.append({
                    'ticker': ticker,
                    'price': row[0] if row else None,
                    'last_updated': row[1] if row else None,
                    'name': info_row[0] if info_row else ticker,
                    'sector': info_row[1] if info_row else 'Ukjent'
                })
            
            if prices:
                prices_df = pd.DataFrame(prices)
                holdings = holdings.merge(prices_df, on='ticker')
                holdings['value'] = holdings['quantity'] * holdings['price'].fillna(0)
                holdings['value_formatted'] = holdings['value'].apply(lambda x: f'{x:,.0f} NOK')
                
                # Vis metrics
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    total_value = holdings['value'].sum()
                    st.metric('Total verdi', f'{total_value:,.0f} NOK')
                
                with col2:
                    # Beregn total investert
                    total_invested = (tx_df[tx_df['quantity'] > 0]['quantity'] * tx_df[tx_df['quantity'] > 0]['price']).sum()
                    st.metric('Total investert', f'{total_invested:,.0f} NOK')
                
                with col3:
                    # Beregn gevinst/tap
                    gain_loss = total_value - total_invested
                    gain_loss_pct = (gain_loss / total_invested * 100) if total_invested > 0 else 0
                    st.metric('Gevinst/Tap', f'{gain_loss:,.0f} NOK', f'{gain_loss_pct:.1f}%')
                
                with col4:
                    # Total utbytte
                    total_divs = pd.read_sql_query('SELECT SUM(amount) as total FROM received_dividends', conn).iloc[0]['total']
                    st.metric('Total utbytte mottatt', f'{total_divs or 0:,.0f} NOK')
                
                st.divider()
                
                # Vis holdings tabell
                display_holdings = holdings[['ticker', 'name', 'sector', 'quantity', 'price', 'value_formatted']].copy()
                display_holdings.columns = ['Ticker', 'Navn', 'Sektor', 'Antall', 'Pris', 'Verdi']
                st.dataframe(display_holdings, use_container_width=True, hide_index=True)
                
                # Porteføljefordeling
                if holdings['value'].sum() > 0:
                    import plotly.express as px
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        fig = px.pie(holdings, names='name', values='value', 
                                    title='Porteføljefordeling',
                                    hover_data=['ticker'])
                        st.plotly_chart(fig, use_container_width=True)
                    
                    with col2:
                        # Sektorfordeling
                        sector_group = holdings.groupby('sector')['value'].sum().reset_index()
                        fig2 = px.pie(sector_group, names='sector', values='value',
                                     title='Sektorfordeling')
                        st.plotly_chart(fig2, use_container_width=True)
        else:
            st.info('Ingen transaksjoner registrert ennå. Legg til din første transaksjon i "Transaksjoner"-fanen.')
    
    with tab2:
        st.header('💼 Transaksjoner')
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            with st.form('transaction_form', clear_on_submit=True):
                st.subheader('Ny transaksjon')
                
                tickers_df = load_tickers(conn)
                ticker_options = [''] + sorted(tickers_df['ticker'].tolist())
                
                ticker = st.selectbox('Velg ticker', ticker_options)
                if ticker == '':
                    ticker_manual = st.text_input('...eller skriv inn ticker manuelt')
                    ticker = ticker_manual.upper() if ticker_manual else None
                
                date = st.date_input('Dato', value=datetime.date.today())
                tx_type = st.radio('Type', ['Kjøp', 'Salg'])
                quantity = st.number_input('Antall aksjer', min_value=0.0, format="%.2f")
                price = st.number_input('Pris per aksje (NOK)', min_value=0.0, format="%.2f")
                fee = st.number_input('Kurtasje (NOK)', min_value=0.0, value=0.0, format="%.2f")
                notes = st.text_area('Notater', height=100)
                
                if st.form_submit_button('Registrer transaksjon', type='primary'):
                    if ticker and quantity > 0 and price > 0:
                        actual_quantity = quantity if tx_type == 'Kjøp' else -quantity
                        cur = conn.cursor()
                        cur.execute("""
                            INSERT INTO transactions (date, ticker, quantity, price, fee, notes)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (date.isoformat(), ticker, actual_quantity, price, fee, notes))
                        conn.commit()
                        st.success(f'✅ {tx_type} av {quantity} {ticker} registrert!')
                        st.rerun()
                    else:
                        st.error('Vennligst fyll ut alle påkrevde felt')
        
        with col2:
            st.subheader('Transaksjonshistorikk')
            tx_df = pd.read_sql_query('SELECT * FROM transactions ORDER BY date DESC', conn)
            if not tx_df.empty:
                tx_display = tx_df.copy()
                tx_display['type'] = tx_display['quantity'].apply(lambda x: 'Kjøp' if x > 0 else 'Salg')
                tx_display['quantity'] = tx_display['quantity'].abs()
                tx_display['total'] = tx_display['quantity'] * tx_display['price'] + tx_display['fee']
                tx_display = tx_display[['date', 'ticker', 'type', 'quantity', 'price', 'fee', 'total', 'notes']]
                st.dataframe(tx_display, use_container_width=True, hide_index=True)
            else:
                st.info('Ingen transaksjoner registrert ennå')
    
    with tab3:
        st.header('💰 Utbytter')
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            with st.form('dividend_form', clear_on_submit=True):
                st.subheader('Registrer mottatt utbytte')
                
                # Hent holdings for dropdown
                holdings_query = """
                    SELECT DISTINCT ticker 
                    FROM transactions 
                    GROUP BY ticker 
                    HAVING SUM(quantity) > 0
                    ORDER BY ticker
                """
                holdings_df = pd.read_sql_query(holdings_query, conn)
                ticker_options = [''] + holdings_df['ticker'].tolist()
                
                ticker = st.selectbox('Velg ticker', ticker_options, key='div_ticker')
                date = st.date_input('Dato mottatt', value=datetime.date.today(), key='div_date')
                amount = st.number_input('Beløp mottatt (NOK)', min_value=0.0, format="%.2f", key='div_amount')
                
                # Beregn antall aksjer på utbyttetidspunkt
                if ticker:
                    shares_query = """
                        SELECT SUM(quantity) as shares
                        FROM transactions
                        WHERE ticker = ? AND date <= ?
                    """
                    shares_result = pd.read_sql_query(shares_query, conn, params=(ticker, date.isoformat()))
                    shares_held = shares_result.iloc[0]['shares'] if not shares_result.empty else 0
                    st.info(f'Aksjer eid på denne datoen: {shares_held:.0f}')
                    per_share = amount / shares_held if shares_held > 0 else 0
                else:
                    shares_held = 0
                    per_share = 0
                
                notes = st.text_area('Notater', height=100, key='div_notes')
                
                if st.form_submit_button('Registrer utbytte', type='primary'):
                    if ticker and amount > 0:
                        cur = conn.cursor()
                        cur.execute("""
                            INSERT INTO received_dividends (date, ticker, amount, shares_held, per_share, notes)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (date.isoformat(), ticker, amount, shares_held, per_share, notes))
                        conn.commit()
                        st.success(f'✅ Utbytte på {amount:.2f} NOK fra {ticker} registrert!')
                        st.rerun()
                    else:
                        st.error('Vennligst fyll ut ticker og beløp')
        
        with col2:
            st.subheader('Utbyttehistorikk')
            
            # Mottatte utbytter
            st.markdown('**Mottatte utbytter**')
            divs_df = pd.read_sql_query('SELECT * FROM received_dividends ORDER BY date DESC', conn)
            if not divs_df.empty:
                divs_display = divs_df[['date', 'ticker', 'amount', 'shares_held', 'per_share', 'notes']].copy()
                divs_display.columns = ['Dato', 'Ticker', 'Beløp (NOK)', 'Aksjer eid', 'Per aksje', 'Notater']
                st.dataframe(divs_display, use_container_width=True, hide_index=True)
                
                # Oppsummering
                total_divs = divs_df['amount'].sum()
                st.success(f'**Totalt mottatt utbytte: {total_divs:,.2f} NOK**')
            else:
                st.info('Ingen utbytter registrert ennå')
            
            st.divider()
            
            # Kommende utbytter
            st.markdown('**Historiske utbytter fra Yahoo Finance**')
            hist_divs = pd.read_sql_query("""
                SELECT ticker, date, dividend 
                FROM historical_dividends 
                ORDER BY date DESC 
                LIMIT 50
            """, conn)
            
            if not hist_divs.empty:
                st.dataframe(hist_divs, use_container_width=True, hide_index=True)
            else:
                st.info('Ingen historiske utbytter hentet ennå. Klikk "Oppdater alle markedsdata" i sidemenyen.')
    
    with tab4:
        st.header('🏢 Selskapsdetaljer')
        
        tickers_df = load_tickers(conn)
        
        if tickers_df.empty:
            st.warning('Ingen selskaper lastet. Last inn Oslo Børs-aksjer først i sidemenyen.')
        else:
            # Seleksjonsboks for å velge selskap
            col1, col2, col3 = st.columns([2, 2, 1])
            
            with col1:
                # Lag en liste med ticker og navn for bedre brukeropplevelse
                ticker_display = tickers_df.apply(lambda x: f"{x['ticker']} - {x['name']}" if pd.notna(x['name']) else x['ticker'], axis=1).tolist()
                ticker_map = dict(zip(ticker_display, tickers_df['ticker'].tolist()))
                
                selected_display = st.selectbox(
                    '🔍 Velg selskap',
                    [''] + ticker_display,
                    help='Velg et selskap for å se detaljert informasjon'
                )
            
            if selected_display and selected_display != '':
                selected_ticker = ticker_map[selected_display]
                
                # Hent all informasjon om valgt selskap
                cur = conn.cursor()
                
                # Hent grunnleggende info
                cur.execute("""
                    SELECT t.*, m.last_price, m.last_updated, m.dividends_json, m.info_json
                    FROM tickers t
                    LEFT JOIN market_cache m ON t.ticker = m.ticker
                    WHERE t.ticker = ?
                """, (selected_ticker,))
                company_info = cur.fetchone()
                
                if company_info:
                    st.divider()
                    
                    # Overskrift med selskapsnavn
                    st.subheader(f"📊 {company_info[1] if company_info[1] else selected_ticker}")
                    
                    # Nøkkelinformasjon i kolonner
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Ticker", selected_ticker)
                        if company_info[2]:  # Sektor
                            st.metric("Sektor", company_info[2])
                    
                    with col2:
                        if company_info[6]:  # Siste pris
                            st.metric("Siste kurs", f"{company_info[6]:.2f} NOK")
                        if company_info[3]:  # Industri
                            st.metric("Industri", company_info[3])
                    
                    with col3:
                        if company_info[4]:  # Market cap
                            market_cap_billions = company_info[4] / 1_000_000_000
                            st.metric("Markedsverdi", f"{market_cap_billions:.1f} mrd NOK")
                        if company_info[7]:  # Sist oppdatert
                            last_updated = datetime.datetime.fromisoformat(company_info[7])
                            st.metric("Sist oppdatert", last_updated.strftime("%Y-%m-%d %H:%M"))
                    
                    with col4:
                        # Beregn utbytteavkastning
                        metrics = calculate_dividend_metrics(conn, selected_ticker)
                        if metrics and metrics.get('dividend_yield'):
                            st.metric("Utbytteavkastning", f"{metrics['dividend_yield']:.2f}%")
                        if metrics and metrics.get('total_dividends_last_year'):
                            st.metric("Årlig utbytte", f"{metrics['total_dividends_last_year']:.2f} NOK")
                    
                    # Din portefølje i dette selskapet
                    st.divider()
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        st.markdown("### 💼 Din posisjon")
                        
                        # Hent transaksjoner for dette selskapet
                        tx_query = """
                            SELECT date, quantity, price, fee,
                                   CASE WHEN quantity > 0 THEN 'Kjøp' ELSE 'Salg' END as type
                            FROM transactions 
                            WHERE ticker = ?
                            ORDER BY date DESC
                        """
                        tx_company = pd.read_sql_query(tx_query, conn, params=(selected_ticker,))
                        
                        if not tx_company.empty:
                            # Beregn total posisjon
                            total_shares = tx_company['quantity'].sum()
                            
                            if total_shares > 0:
                                avg_price_query = """
                                    SELECT 
                                        SUM(CASE WHEN quantity > 0 THEN quantity * price ELSE 0 END) / 
                                        SUM(CASE WHEN quantity > 0 THEN quantity ELSE 0 END) as avg_price
                                    FROM transactions 
                                    WHERE ticker = ? AND quantity > 0
                                """
                                avg_price_result = pd.read_sql_query(avg_price_query, conn, params=(selected_ticker,))
                                avg_price = avg_price_result.iloc[0]['avg_price'] if not avg_price_result.empty else 0
                                
                                current_value = total_shares * company_info[6] if company_info[6] else 0
                                invested_value = total_shares * avg_price if avg_price else 0
                                gain_loss = current_value - invested_value
                                gain_loss_pct = (gain_loss / invested_value * 100) if invested_value > 0 else 0
                                
                                mcol1, mcol2 = st.columns(2)
                                with mcol1:
                                    st.metric("Antall aksjer", f"{total_shares:.0f}")
                                    st.metric("Gjennomsnittspris", f"{avg_price:.2f} NOK" if avg_price else "N/A")
                                
                                with mcol2:
                                    st.metric("Nåværende verdi", f"{current_value:,.0f} NOK")
                                    st.metric("Gevinst/Tap", f"{gain_loss:,.0f} NOK", f"{gain_loss_pct:.1f}%")
                            else:
                                st.info("Du eier ikke aksjer i dette selskapet lenger")
                            
                            # Vis transaksjonshistorikk
                            with st.expander("📜 Transaksjonshistorikk"):
                                tx_display = tx_company.copy()
                                tx_display['quantity'] = tx_display['quantity'].abs()
                                tx_display['total'] = tx_display['quantity'] * tx_display['price'] + tx_display['fee']
                                tx_display = tx_display[['date', 'type', 'quantity', 'price', 'total']]
                                tx_display.columns = ['Dato', 'Type', 'Antall', 'Pris', 'Total']
                                st.dataframe(tx_display, use_container_width=True, hide_index=True)
                        else:
                            st.info("Du har ingen transaksjoner i dette selskapet")
                    
                    with col2:
                        st.markdown("### 💰 Mottatte utbytter")
                        
                        # Hent mottatte utbytter for dette selskapet
                        divs_received_query = """
                            SELECT date, amount, shares_held, per_share
                            FROM received_dividends
                            WHERE ticker = ?
                            ORDER BY date DESC
                        """
                        divs_received = pd.read_sql_query(divs_received_query, conn, params=(selected_ticker,))
                        
                        if not divs_received.empty:
                            total_received = divs_received['amount'].sum()
                            st.metric("Totalt mottatt", f"{total_received:,.2f} NOK")
                            st.metric("Antall utbetalinger", f"{len(divs_received)}")
                            
                            with st.expander("📜 Utbyttehistorikk (mottatt)"):
                                divs_display = divs_received[['date', 'amount', 'shares_held', 'per_share']].copy()
                                divs_display.columns = ['Dato', 'Beløp', 'Aksjer eid', 'Per aksje']
                                st.dataframe(divs_display, use_container_width=True, hide_index=True)
                        else:
                            st.info("Du har ikke mottatt utbytte fra dette selskapet ennå")
                    
                    # Historiske utbytter fra Yahoo Finance
                    st.divider()
                    st.markdown("### 📈 Historiske utbytter (Yahoo Finance)")
                    
                    # Hent historiske utbytter
                    hist_divs_query = """
                        SELECT date, dividend 
                        FROM historical_dividends 
                        WHERE ticker = ?
                        ORDER BY date DESC
                    """
                    hist_divs = pd.read_sql_query(hist_divs_query, conn, params=(selected_ticker,))
                    
                    if not hist_divs.empty:
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            # Graf over utbyttehistorikk
                            import plotly.graph_objects as go
                            
                            # Konverter dato til datetime for plotting
                            hist_divs['date'] = pd.to_datetime(hist_divs['date'])
                            hist_divs_plot = hist_divs.sort_values('date')
                            
                            fig = go.Figure()
                            
                            # Legg til stolpediagram for utbytter
                            fig.add_trace(go.Bar(
                                x=hist_divs_plot['date'],
                                y=hist_divs_plot['dividend'],
                                name='Utbytte per aksje',
                                marker_color='#0051A3',
                                text=hist_divs_plot['dividend'].apply(lambda x: f'{x:.2f}'),
                                textposition='outside',
                            ))
                            
                            # Legg til trendlinje
                            fig.add_trace(go.Scatter(
                                x=hist_divs_plot['date'],
                                y=hist_divs_plot['dividend'],
                                mode='lines+markers',
                                name='Trend',
                                line=dict(color='red', width=2, dash='dash'),
                                marker=dict(size=8)
                            ))
                            
                            fig.update_layout(
                                title=f'Utbyttehistorikk for {selected_ticker}',
                                xaxis_title='Dato',
                                yaxis_title='Utbytte per aksje (NOK)',
                                hovermode='x unified',
                                showlegend=True,
                                height=400
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                            
                            # Årlig aggregert utbytte
                            hist_divs['year'] = hist_divs['date'].dt.year
                            annual_divs = hist_divs.groupby('year')['dividend'].agg(['sum', 'count']).reset_index()
                            annual_divs.columns = ['År', 'Total utbytte', 'Antall utbetalinger']
                            
                            fig2 = go.Figure()
                            fig2.add_trace(go.Bar(
                                x=annual_divs['År'],
                                y=annual_divs['Total utbytte'],
                                text=annual_divs['Total utbytte'].apply(lambda x: f'{x:.2f}'),
                                textposition='outside',
                                marker_color='#28a745'
                            ))
                            
                            fig2.update_layout(
                                title='Årlig utbytte per aksje',
                                xaxis_title='År',
                                yaxis_title='Total utbytte per aksje (NOK)',
                                height=300
                            )
                            
                            st.plotly_chart(fig2, use_container_width=True)
                        
                        with col2:
                            st.markdown("#### 📊 Statistikk")
                            
                            # Beregn statistikk
                            total_divs = len(hist_divs)
                            avg_dividend = hist_divs['dividend'].mean()
                            max_dividend = hist_divs['dividend'].max()
                            min_dividend = hist_divs['dividend'].min()
                            std_dividend = hist_divs['dividend'].std()
                            
                            # Finn siste og neste utbytte
                            last_div_date = hist_divs['date'].max()
                            last_dividend = hist_divs[hist_divs['date'] == last_div_date]['dividend'].iloc[0]
                            
                            st.metric("Antall utbetalinger", f"{total_divs}")
                            st.metric("Gjennomsnitt per utbetaling", f"{avg_dividend:.2f} NOK")
                            st.metric("Høyeste utbytte", f"{max_dividend:.2f} NOK")
                            st.metric("Laveste utbytte", f"{min_dividend:.2f} NOK")
                            st.metric("Standardavvik", f"{std_dividend:.2f}")
                            st.metric("Siste utbytte", f"{last_dividend:.2f} NOK")
                            st.metric("Siste utbyttedato", last_div_date.strftime("%Y-%m-%d"))
                            
                            # Beregn CAGR for utbytte hvis vi har nok data
                            if len(annual_divs) > 1:
                                first_year = annual_divs['År'].min()
                                last_year = annual_divs['År'].max()
                                first_total = annual_divs[annual_divs['År'] == first_year]['Total utbytte'].iloc[0]
                                last_total = annual_divs[annual_divs['År'] == last_year]['Total utbytte'].iloc[0]
                                
                                if first_total > 0:
                                    years = last_year - first_year
                                    if years > 0:
                                        cagr = ((last_total / first_total) ** (1/years) - 1) * 100
                                        st.metric("Årlig vekst (CAGR)", f"{cagr:.1f}%")
                        
                        # Detaljert tabell
                        with st.expander("📋 Alle historiske utbytter"):
                            hist_divs_display = hist_divs[['date', 'dividend']].copy()
                            hist_divs_display['date'] = hist_divs_display['date'].dt.strftime('%Y-%m-%d')
                            hist_divs_display.columns = ['Dato', 'Utbytte per aksje (NOK)']
                            hist_divs_display = hist_divs_display.sort_values('Dato', ascending=False)
                            st.dataframe(hist_divs_display, use_container_width=True, hide_index=True)
                            
                            # Last ned som CSV
                            csv = hist_divs_display.to_csv(index=False).encode('utf-8')
                            st.download_button(
                                label=f"Last ned utbyttehistorikk for {selected_ticker}",
                                data=csv,
                                file_name=f'{selected_ticker}_dividends_{datetime.date.today()}.csv',
                                mime='text/csv'
                            )
                    else:
                        st.info(f"Ingen historiske utbytter funnet for {selected_ticker}. Klikk 'Oppdater alle markedsdata' i sidemenyen for å hente data.")
                    
                    # Oppdater enkeltselskap
                    st.divider()
                    if st.button(f"🔄 Oppdater data for {selected_ticker}", type='secondary'):
                        with st.spinner(f'Henter oppdatert data for {selected_ticker}...'):
                            results = fetch_market_data([selected_ticker])
                            if selected_ticker in results and 'error' not in results[selected_ticker]:
                                data = results[selected_ticker]
                                
                                # Oppdater ticker info
                                upsert_ticker(
                                    conn, selected_ticker,
                                    name=data.get('name'),
                                    sector=data.get('sector'),
                                    industry=data.get('industry'),
                                    market_cap=data.get('market_cap')
                                )
                                
                                # Oppdater market cache og utbytter
                                cur = conn.cursor()
                                cur.execute("""
                                    INSERT OR REPLACE INTO market_cache 
                                    (ticker, last_price, last_updated, dividends_json, info_json)
                                    VALUES (?, ?, ?, ?, ?)
                                """, (
                                    selected_ticker,
                                    data.get('price'),
                                    datetime.datetime.utcnow().isoformat(),
                                    json.dumps(data.get('dividends', [])),
                                    json.dumps(data.get('info', {}))
                                ))
                                
                                # Oppdater historiske utbytter
                                for div in data.get('dividends', []):
                                    cur.execute("""
                                        INSERT OR REPLACE INTO historical_dividends
                                        (ticker, date, dividend)
                                        VALUES (?, ?, ?)
                                    """, (selected_ticker, div['date'], div['dividend']))
                                
                                conn.commit()
                                st.success(f'✅ Data for {selected_ticker} oppdatert!')
                                st.rerun()
                            else:
                                st.error(f'Kunne ikke hente data for {selected_ticker}')
    
    with tab5:
        st.header('📈 Analyse')
        
        # Utbytteanalyse
        st.subheader('Utbytteanalyse')
        
        tickers_df = load_tickers(conn)
        if not tickers_df.empty:
            dividend_data = []
            
            for ticker in tickers_df['ticker']:
                metrics = calculate_dividend_metrics(conn, ticker)
                if metrics:
                    # Hent navn
                    cur = conn.cursor()
                    cur.execute("SELECT name FROM tickers WHERE ticker = ?", (ticker,))
                    name_row = cur.fetchone()
                    
                    dividend_data.append({
                        'Ticker': ticker,
                        'Navn': name_row[0] if name_row else ticker,
                        'Siste utbytte': f"{metrics.get('last_dividend', 0):.2f}",
                        'Siste utb. dato': metrics.get('last_dividend_date', '-'),
                        'Årlig utbytte': f"{metrics.get('total_dividends_last_year', 0):.2f}",
                        'Utbytteavkastning': f"{metrics.get('dividend_yield', 0):.2f}%",
                        'Antall utdelinger': metrics.get('dividend_count_last_year', 0)
                    })
            
            if dividend_data:
                div_analysis_df = pd.DataFrame(dividend_data)
                # Sorter etter utbytteavkastning
                div_analysis_df['sort_yield'] = div_analysis_df['Utbytteavkastning'].str.rstrip('%').astype(float)
                div_analysis_df = div_analysis_df.sort_values('sort_yield', ascending=False).drop('sort_yield', axis=1)
                
                st.dataframe(div_analysis_df, use_container_width=True, hide_index=True)
                
                # Visualisering
                if len(dividend_data) > 0:
                    import plotly.graph_objects as go
                    
                    top_10 = div_analysis_df.head(10)
                    fig = go.Figure(data=[
                        go.Bar(
                            x=top_10['Ticker'],
                            y=top_10['Utbytteavkastning'].str.rstrip('%').astype(float),
                            text=top_10['Utbytteavkastning'],
                            textposition='auto',
                        )
                    ])
                    fig.update_layout(
                        title='Topp 10 aksjer etter utbytteavkastning',
                        xaxis_title='Ticker',
                        yaxis_title='Utbytteavkastning (%)',
                        showlegend=False
                    )
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.info('Ingen utbyttedata tilgjengelig. Oppdater markedsdata først.')
        else:
            st.warning('Ingen tickers lastet. Last inn Oslo Børs-aksjer først.')
    
    with tab6:
        st.header('⚙️ Data')
        
        # Vis alle tabeller
        st.subheader('Database-tabeller')
        
        tables = ['tickers', 'transactions', 'received_dividends', 'market_cache', 'historical_dividends']
        
        selected_table = st.selectbox('Velg tabell', tables)
        
        try:
            df = pd.read_sql_query(f'SELECT * FROM {selected_table}', conn)
            st.dataframe(df, use_container_width=True)
            
            # Last ned som CSV
            csv = df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label=f"Last ned {selected_table} som CSV",
                data=csv,
                file_name=f'{selected_table}_{datetime.date.today()}.csv',
                mime='text/csv'
            )
        except Exception as e:
            st.error(f'Kunne ikke lese tabell: {e}')

if __name__ == '__main__':
    main()
