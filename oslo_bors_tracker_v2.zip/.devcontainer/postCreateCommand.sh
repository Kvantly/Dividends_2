#!/bin/bash

echo "🚀 Setting up Oslo Børs Portfolio Tracker in GitHub Codespaces..."
echo "============================================================="

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Install Python dependencies
echo -e "${BLUE}📦 Installing Python packages...${NC}"
pip install --upgrade pip
pip install -r requirements.txt

# Initialize the database
echo -e "${BLUE}🗄️ Initializing database...${NC}"
python db_init.py

# Create a sample data option file
echo -e "${BLUE}📊 Setting up sample data...${NC}"
python db_init.py --with-samples

# Create a startup script for Codespaces
cat > start_codespaces.sh << 'EOF'
#!/bin/bash
echo "🚀 Starting Oslo Børs Portfolio Tracker..."
echo "=========================================="
echo ""
echo "📱 The app will open automatically in a new browser tab"
echo "If not, click on the 'Ports' tab and open port 8501"
echo ""
echo "Press Ctrl+C to stop the application"
echo "=========================================="

# Start Streamlit with Codespaces-friendly settings
streamlit run app.py --server.address=0.0.0.0 --server.port=8501
EOF

chmod +x start_codespaces.sh

# Create a quick test script
echo -e "${BLUE}🧪 Running quick test...${NC}"
python -c "
import sqlite3
import pandas as pd
conn = sqlite3.connect('data.db')
tickers = pd.read_sql_query('SELECT COUNT(*) as count FROM tickers', conn)
print(f'✅ Database initialized with {tickers.iloc[0][\"count\"]} tickers')
conn.close()
"

# Display helpful information
echo ""
echo -e "${GREEN}✅ Setup complete!${NC}"
echo ""
echo "============================================================="
echo " QUICK START GUIDE FOR GITHUB CODESPACES"
echo "============================================================="
echo ""
echo "1. To start the app, run:"
echo "   ${GREEN}streamlit run app.py${NC}"
echo ""
echo "   Or use the custom script:"
echo "   ${GREEN}./start_codespaces.sh${NC}"
echo ""
echo "2. The app will open automatically in a new browser tab"
echo "   If not, go to the 'Ports' tab and click on port 8501"
echo ""
echo "3. First time setup in the app:"
echo "   - Click '🔄 Last inn Oslo Børs aksjer' in the sidebar"
echo "   - Click '📊 Oppdater alle markedsdata' to fetch prices"
echo ""
echo "4. To test yfinance connectivity:"
echo "   ${GREEN}python test_yfinance.py${NC}"
echo ""
echo "5. To update all Oslo Børs data:"
echo "   ${GREEN}python update_oslo_bors.py${NC}"
echo ""
echo "============================================================="
echo ""
echo "📚 Full documentation: See README.md"
echo "💡 Tip: The database already contains sample transactions!"
echo ""
