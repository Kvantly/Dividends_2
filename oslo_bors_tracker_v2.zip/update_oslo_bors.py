#!/usr/bin/env python3
"""
Utility script to fetch Oslo Børs tickers and update market data
"""

import yfinance as yf
import pandas as pd
import sqlite3
from datetime import datetime, timedelta
import time
import json

def get_all_oslo_bors_tickers():
    """
    Get an extended list of Oslo Børs tickers
    Note: This is a curated list. For a complete list, 
    you would need to scrape Oslo Børs website or use their API
    """
    
    # Main index stocks (OBX - top 25)
    obx_stocks = [
        "EQNR.OL", "DNB.OL", "TEL.OL", "MOWI.OL", "YAR.OL", 
        "ORK.OL", "AKRBP.OL", "NHY.OL", "SALM.OL", "SUBC.OL",
        "TGS.OL", "GJFS.OL", "STB.OL", "SCHR.OL", "KOG.OL",
        "TOM.OL", "NEL.OL", "BWLPG.OL", "AKSO.OL", "PGS.OL",
        "NOD.OL", "ENTRA.OL", "RECSI.OL", "BWO.OL", "AKA.OL"
    ]
    
    # Additional large and mid-cap stocks
    additional_stocks = [
        "NONG.OL", "SRBANK.OL", "BAKKA.OL", "AFG.OL", "LSG.OL",
        "KAHOT.OL", "CRAYN.OL", "NEXT.OL", "B2H.OL", "KIT.OL",
        "WAWI.OL", "SDRL.OL", "PEXIP.OL", "VEI.OL", "ZAL.OL",
        "XXL.OL", "IDEX.OL", "NAS.OL", "FLYR.OL", "NAPA.OL",
        "OLT.OL", "SATS.OL", "GOGL.OL", "ATEA.OL", "AUSS.OL",
        "AUTO.OL", "BONHR.OL", "BRG.OL", "EMGS.OL", "EPR.OL",
        "GJF.OL", "GSF.OL", "HEX.OL", "KID.OL", "KOA.OL",
        "LINK.OL", "MPCC.OL", "MULTI.OL", "NRC.OL", "ODFB.OL",
        "PARB.OL", "PROTCT.OL", "QFR.OL", "REACH.OL", "SAGA.OL",
        "SCHA.OL", "SCHB.OL", "SNI.OL", "SOAG.OL", "SPOG.OL",
        "SSO.OL", "STRO.OL", "THIN.OL", "ULTI.OL", "VAR.OL"
    ]
    
    # Small cap interesting stocks
    small_cap = [
        "ABG.OL", "ACC.OL", "ARCH.OL", "ASTK.OL", "ATRO.OL",
        "AURG.OL", "AUSS.OL", "AVANCE.OL", "AXA.OL", "BGBIO.OL",
        "BOUVET.OL", "BMA.OL", "BWEK.OL", "CARA.OL", "CONTX.OL",
        "DNO.OL", "DOF.OL", "EIOF.OL", "ELE.OL", "ELK.OL",
        "ELMRA.OL", "ENSU.OL", "FRO.OL", "GOD.OL", "HAFNI.OL",
        "HAVI.OL", "HBC.OL", "HPUR.OL", "HUNT.OL", "HYN.OL",
        "INSR.OL", "IOX.OL", "JIN.OL", "KCC.OL", "KMCP.OL",
        "KVE.OL", "LIFE.OL", "MEDI.OL", "MGN.OL", "MPC.OL"
    ]
    
    # Combine all lists and remove duplicates
    all_tickers = list(set(obx_stocks + additional_stocks + small_cap))
    return sorted(all_tickers)

def validate_ticker(ticker):
    """
    Validate if a ticker exists and has data on Yahoo Finance
    """
    try:
        tk = yf.Ticker(ticker)
        hist = tk.history(period="5d")
        if hist.empty:
            return False, None
        
        info = tk.info
        return True, info
    except:
        return False, None

def fetch_dividend_history(ticker, start_date=None):
    """
    Fetch complete dividend history for a ticker
    """
    try:
        tk = yf.Ticker(ticker)
        
        if start_date is None:
            # Get last 10 years by default
            start_date = datetime.now() - timedelta(days=3650)
        
        dividends = tk.dividends
        if dividends.empty:
            return []
        
        # Convert to list of dicts
        div_list = []
        for date, amount in dividends.items():
            div_list.append({
                'date': date.strftime('%Y-%m-%d'),
                'amount': float(amount),
                'ticker': ticker
            })
        
        return div_list
    except Exception as e:
        print(f"Error fetching dividends for {ticker}: {e}")
        return []

def calculate_dividend_metrics(ticker, price, dividends):
    """
    Calculate dividend metrics for a ticker
    """
    if not dividends or not price:
        return {}
    
    # Sort dividends by date
    dividends = sorted(dividends, key=lambda x: x['date'], reverse=True)
    
    # Calculate metrics for last 12 months
    one_year_ago = datetime.now() - timedelta(days=365)
    one_year_ago_str = one_year_ago.strftime('%Y-%m-%d')
    
    annual_dividend = 0
    dividend_count = 0
    
    for div in dividends:
        if div['date'] >= one_year_ago_str:
            annual_dividend += div['amount']
            dividend_count += 1
    
    # Calculate yield
    dividend_yield = (annual_dividend / price * 100) if price > 0 else 0
    
    # Find payment frequency
    if dividend_count >= 4:
        frequency = "Quarterly"
    elif dividend_count >= 2:
        frequency = "Semi-annual"
    elif dividend_count == 1:
        frequency = "Annual"
    else:
        frequency = "No recent dividends"
    
    return {
        'annual_dividend': annual_dividend,
        'dividend_yield': dividend_yield,
        'dividend_count': dividend_count,
        'frequency': frequency,
        'last_dividend': dividends[0]['amount'] if dividends else 0,
        'last_dividend_date': dividends[0]['date'] if dividends else None
    }

def update_database_with_tickers(db_path="data.db"):
    """
    Update database with all Oslo Børs tickers and their data
    """
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    
    # Get all tickers
    tickers = get_all_oslo_bors_tickers()
    print(f"Found {len(tickers)} Oslo Børs tickers to process")
    
    successful = 0
    failed = 0
    
    for idx, ticker in enumerate(tickers):
        print(f"Processing {idx+1}/{len(tickers)}: {ticker}...", end="")
        
        # Validate and get info
        valid, info = validate_ticker(ticker)
        
        if not valid:
            print(" ❌ Invalid/No data")
            failed += 1
            continue
        
        try:
            # Get current price
            tk = yf.Ticker(ticker)
            hist = tk.history(period="5d")
            price = float(hist['Close'].iloc[-1]) if not hist.empty else None
            
            # Get company info
            name = info.get('longName') or info.get('shortName', ticker)
            sector = info.get('sector', 'Unknown')
            industry = info.get('industry', 'Unknown')
            market_cap = info.get('marketCap', 0)
            
            # Update ticker table
            cur.execute("""
                INSERT OR REPLACE INTO tickers (ticker, name, sector, industry, market_cap, last_updated)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (ticker, name, sector, industry, market_cap, datetime.utcnow().isoformat()))
            
            # Get dividend history
            dividends = fetch_dividend_history(ticker)
            
            # Update market cache
            cur.execute("""
                INSERT OR REPLACE INTO market_cache (ticker, last_price, last_updated, dividends_json, info_json)
                VALUES (?, ?, ?, ?, ?)
            """, (
                ticker,
                price,
                datetime.utcnow().isoformat(),
                json.dumps(dividends),
                json.dumps(info)
            ))
            
            # Update historical dividends
            for div in dividends:
                cur.execute("""
                    INSERT OR REPLACE INTO historical_dividends (ticker, date, dividend)
                    VALUES (?, ?, ?)
                """, (ticker, div['date'], div['amount']))
            
            # Calculate and display metrics
            if price and dividends:
                metrics = calculate_dividend_metrics(ticker, price, dividends)
                if metrics['dividend_yield'] > 0:
                    print(f" ✅ Price: {price:.2f} NOK, Yield: {metrics['dividend_yield']:.2f}%")
                else:
                    print(f" ✅ Price: {price:.2f} NOK, No dividends")
            else:
                print(f" ✅ Price: {price:.2f} NOK" if price else " ✅ Added")
            
            successful += 1
            conn.commit()
            
            # Small delay to avoid rate limiting
            time.sleep(0.2)
            
        except Exception as e:
            print(f" ❌ Error: {e}")
            failed += 1
            continue
    
    conn.close()
    
    print("\n" + "="*50)
    print(f"✅ Successfully processed: {successful} tickers")
    print(f"❌ Failed: {failed} tickers")
    print(f"📊 Total: {len(tickers)} tickers")
    
    return successful, failed

def find_top_dividend_stocks(db_path="data.db", top_n=20):
    """
    Find top dividend-paying stocks from the database
    """
    conn = sqlite3.connect(db_path)
    
    query = """
        SELECT 
            t.ticker,
            t.name,
            t.sector,
            m.last_price,
            m.dividends_json
        FROM tickers t
        JOIN market_cache m ON t.ticker = m.ticker
        WHERE m.last_price IS NOT NULL
    """
    
    df = pd.read_sql_query(query, conn)
    conn.close()
    
    # Calculate dividend metrics for each stock
    results = []
    
    for _, row in df.iterrows():
        try:
            dividends = json.loads(row['dividends_json'])
            if dividends:
                metrics = calculate_dividend_metrics(
                    row['ticker'], 
                    row['last_price'], 
                    dividends
                )
                
                if metrics['dividend_yield'] > 0:
                    results.append({
                        'Ticker': row['ticker'],
                        'Name': row['name'],
                        'Sector': row['sector'],
                        'Price': row['last_price'],
                        'Yield %': metrics['dividend_yield'],
                        'Annual Div': metrics['annual_dividend'],
                        'Frequency': metrics['frequency'],
                        'Last Div Date': metrics['last_dividend_date']
                    })
        except:
            continue
    
    # Sort by yield and get top N
    results_df = pd.DataFrame(results)
    if not results_df.empty:
        results_df = results_df.sort_values('Yield %', ascending=False).head(top_n)
        
        print("\n" + "="*50)
        print(f"🏆 TOP {top_n} DIVIDEND STOCKS ON OSLO BØRS")
        print("="*50)
        
        for idx, row in results_df.iterrows():
            print(f"\n{results_df.index.get_loc(idx) + 1}. {row['Name']} ({row['Ticker']})")
            print(f"   Sector: {row['Sector']}")
            print(f"   Price: {row['Price']:.2f} NOK")
            print(f"   Dividend Yield: {row['Yield %']:.2f}%")
            print(f"   Annual Dividend: {row['Annual Div']:.2f} NOK")
            print(f"   Payment Frequency: {row['Frequency']}")
            print(f"   Last Dividend Date: {row['Last Div Date']}")
        
        return results_df
    else:
        print("No dividend-paying stocks found")
        return pd.DataFrame()

def main():
    """
    Main function to update all Oslo Børs data
    """
    print("🚀 Oslo Børs Data Updater")
    print("="*50)
    
    # Check if database exists
    import os
    if not os.path.exists("data.db"):
        print("❌ Database not found. Please run db_init.py first")
        return
    
    print("\nOptions:")
    print("1. Update all Oslo Børs tickers and data")
    print("2. Find top dividend stocks")
    print("3. Both")
    
    choice = input("\nSelect option (1-3): ")
    
    if choice in ["1", "3"]:
        print("\n📊 Updating Oslo Børs data...")
        update_database_with_tickers()
    
    if choice in ["2", "3"]:
        print("\n💰 Finding top dividend stocks...")
        find_top_dividend_stocks()
    
    print("\n✅ Complete!")

if __name__ == "__main__":
    main()
