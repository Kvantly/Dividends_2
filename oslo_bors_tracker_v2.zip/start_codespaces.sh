#!/bin/bash

# Colors for better visibility
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

clear

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║                                                          ║"
echo "║     📈 OSLO BØRS PORTFOLIO & DIVIDEND TRACKER 📈        ║"
echo "║                                                          ║"
echo "║              Running in GitHub Codespaces                ║"
echo "║                                                          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running in Codespaces
if [ -n "$CODESPACES" ]; then
    echo -e "${GREEN}✅ Detected GitHub Codespaces environment${NC}"
    echo ""
fi

# Check if database exists
if [ ! -f "data.db" ]; then
    echo -e "${YELLOW}⚠️  Database not found. Creating...${NC}"
    python db_init.py --with-samples
    echo -e "${GREEN}✅ Database created with sample data${NC}"
    echo ""
fi

# Quick database check
echo -e "${BLUE}📊 Database Status:${NC}"
python -c "
import sqlite3
import pandas as pd

conn = sqlite3.connect('data.db')

# Count records
tickers = pd.read_sql_query('SELECT COUNT(*) as count FROM tickers', conn).iloc[0]['count']
transactions = pd.read_sql_query('SELECT COUNT(*) as count FROM transactions', conn).iloc[0]['count']
dividends = pd.read_sql_query('SELECT COUNT(*) as count FROM received_dividends', conn).iloc[0]['count']

print(f'   • Tickers: {tickers}')
print(f'   • Transactions: {transactions}')
print(f'   • Dividends: {dividends}')

conn.close()
"
echo ""

# Display connection info
echo -e "${BLUE}🌐 Connection Information:${NC}"
echo -e "   • Local URL: ${GREEN}http://localhost:8501${NC}"

if [ -n "$CODESPACE_NAME" ]; then
    echo -e "   • Public URL: ${GREEN}https://${CODESPACE_NAME}-8501.preview.app.github.dev${NC}"
fi

echo ""
echo -e "${YELLOW}📱 The app will open automatically in a new browser tab${NC}"
echo -e "${YELLOW}   If not, check the 'Ports' tab at the bottom of VS Code${NC}"
echo ""

# Instructions
echo -e "${BLUE}📝 Quick Instructions:${NC}"
echo "   1. Wait for the app to start (5-10 seconds)"
echo "   2. Browser tab opens automatically"
echo "   3. First time? Click '🔄 Last inn Oslo Børs aksjer'"
echo "   4. Then click '📊 Oppdater alle markedsdata'"
echo ""
echo -e "${RED}Press Ctrl+C to stop the application${NC}"
echo ""
echo "══════════════════════════════════════════════════════════"
echo ""

# Start Streamlit with proper settings for Codespaces
if [ -n "$CODESPACES" ]; then
    # In Codespaces, bind to all interfaces
    streamlit run app.py \
        --server.address=0.0.0.0 \
        --server.port=8501 \
        --server.headless=true \
        --browser.gatherUsageStats=false \
        --theme.primaryColor="#0051A3" \
        --theme.backgroundColor="#FFFFFF" \
        --theme.secondaryBackgroundColor="#F0F2F6" \
        --theme.textColor="#262730"
else
    # Local development
    streamlit run app.py
fi
