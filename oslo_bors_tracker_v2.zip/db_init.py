#!/usr/bin/env python3
"""
Database initialization script for Oslo Børs Portfolio Tracker
"""

import sqlite3
import pandas as pd
from datetime import datetime
import sys

DB_NAME = "data.db"

def create_tables(conn):
    """Create all necessary database tables"""
    cur = conn.cursor()
    
    # Tickers table - stores stock information
    cur.execute("""
        CREATE TABLE IF NOT EXISTS tickers (
            ticker TEXT PRIMARY KEY,
            name TEXT,
            sector TEXT,
            industry TEXT,
            market_cap REAL,
            last_updated TEXT
        )
    """)
    
    # Transactions table - stores buy/sell transactions
    cur.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            ticker TEXT NOT NULL,
            quantity REAL NOT NULL,
            price REAL NOT NULL,
            fee REAL DEFAULT 0,
            notes TEXT,
            FOREIGN KEY (ticker) REFERENCES tickers(ticker)
        )
    """)
    
    # Received dividends table - stores dividend payments received
    cur.execute("""
        CREATE TABLE IF NOT EXISTS received_dividends (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            ticker TEXT NOT NULL,
            amount REAL NOT NULL,
            shares_held REAL,
            per_share REAL,
            notes TEXT,
            FOREIGN KEY (ticker) REFERENCES tickers(ticker)
        )
    """)
    
    # Market cache table - stores latest market data
    cur.execute("""
        CREATE TABLE IF NOT EXISTS market_cache (
            ticker TEXT PRIMARY KEY,
            last_price REAL,
            last_updated TEXT,
            dividends_json TEXT,
            info_json TEXT,
            FOREIGN KEY (ticker) REFERENCES tickers(ticker)
        )
    """)
    
    # Historical dividends table - stores dividend history from Yahoo Finance
    cur.execute("""
        CREATE TABLE IF NOT EXISTS historical_dividends (
            ticker TEXT,
            date TEXT,
            dividend REAL,
            PRIMARY KEY (ticker, date),
            FOREIGN KEY (ticker) REFERENCES tickers(ticker)
        )
    """)
    
    # Create indexes for better performance
    cur.execute("CREATE INDEX IF NOT EXISTS idx_transactions_ticker ON transactions(ticker)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_dividends_ticker ON received_dividends(ticker)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_dividends_date ON received_dividends(date)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_hist_div_ticker ON historical_dividends(ticker)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_hist_div_date ON historical_dividends(date)")
    
    conn.commit()
    print("✅ Database tables created successfully")

def load_sample_tickers(conn, filename='oslo_bors_tickers.csv'):
    """Load sample tickers from CSV file"""
    try:
        df = pd.read_csv(filename)
        
        cur = conn.cursor()
        for _, row in df.iterrows():
            cur.execute("""
                INSERT OR REPLACE INTO tickers (ticker, name, sector, industry, last_updated)
                VALUES (?, ?, ?, ?, ?)
            """, (
                row['ticker'],
                row.get('name'),
                row.get('sector'),
                row.get('industry'),
                datetime.utcnow().isoformat()
            ))
        
        conn.commit()
        print(f"✅ Loaded {len(df)} tickers from {filename}")
        return True
    except FileNotFoundError:
        print(f"⚠️  File {filename} not found, skipping ticker import")
        return False
    except Exception as e:
        print(f"❌ Error loading tickers: {e}")
        return False

def load_default_oslo_tickers(conn):
    """Load default Oslo Børs tickers if no CSV file exists"""
    default_tickers = [
        ("EQNR.OL", "Equinor ASA", "Energy", "Oil & Gas"),
        ("DNB.OL", "DNB Bank ASA", "Financials", "Banking"),
        ("TEL.OL", "Telenor ASA", "Communication Services", "Telecom"),
        ("MOWI.OL", "Mowi ASA", "Consumer Staples", "Food Products"),
        ("YAR.OL", "Yara International ASA", "Materials", "Chemicals"),
        ("ORK.OL", "Orkla ASA", "Consumer Staples", "Food Products"),
        ("AKRBP.OL", "Aker BP ASA", "Energy", "Oil & Gas"),
        ("NHY.OL", "Norsk Hydro ASA", "Materials", "Aluminum"),
        ("SALM.OL", "SalMar ASA", "Consumer Staples", "Food Products"),
        ("SUBC.OL", "Subsea 7 S.A.", "Energy", "Oil & Gas Services"),
        ("TGS.OL", "TGS ASA", "Energy", "Oil & Gas Services"),
        ("GJFS.OL", "Gjensidige Forsikring ASA", "Financials", "Insurance"),
        ("STB.OL", "Storebrand ASA", "Financials", "Insurance"),
        ("SCHR.OL", "Schibsted ASA", "Communication Services", "Media"),
        ("KOG.OL", "Kongsberg Gruppen ASA", "Industrials", "Aerospace & Defense"),
        ("TOM.OL", "Tomra Systems ASA", "Industrials", "Waste Management"),
        ("NEL.OL", "Nel ASA", "Industrials", "Hydrogen"),
        ("BWLPG.OL", "BW LPG Limited", "Energy", "Oil & Gas Storage"),
        ("AKSO.OL", "Aker Solutions ASA", "Energy", "Oil & Gas Services"),
        ("PGS.OL", "PGS ASA", "Energy", "Oil & Gas Services"),
        ("NOD.OL", "Nordic Semiconductor ASA", "Technology", "Semiconductors"),
        ("ENTRA.OL", "Entra ASA", "Real Estate", "Office REITs"),
        ("RECSI.OL", "REC Silicon ASA", "Materials", "Semiconductors"),
        ("BWO.OL", "BW Offshore Limited", "Energy", "Oil & Gas Services"),
        ("AKA.OL", "Aker ASA", "Financials", "Investment Companies"),
        ("NONG.OL", "SpareBank 1 Nord-Norge", "Financials", "Banking"),
        ("SRBANK.OL", "SpareBank 1 SR-Bank ASA", "Financials", "Banking"),
        ("BAKKA.OL", "Bakkafrost P/F", "Consumer Staples", "Food Products"),
        ("AFG.OL", "Austevoll Seafood ASA", "Consumer Staples", "Food Products"),
        ("LSG.OL", "Lerøy Seafood Group ASA", "Consumer Staples", "Food Products"),
    ]
    
    cur = conn.cursor()
    for ticker, name, sector, industry in default_tickers:
        cur.execute("""
            INSERT OR REPLACE INTO tickers (ticker, name, sector, industry, last_updated)
            VALUES (?, ?, ?, ?, ?)
        """, (ticker, name, sector, industry, datetime.utcnow().isoformat()))
    
    conn.commit()
    print(f"✅ Loaded {len(default_tickers)} default Oslo Børs tickers")

def add_sample_transactions(conn):
    """Add some sample transactions for demonstration"""
    sample_transactions = [
        ("2024-01-15", "EQNR.OL", 100, 350.50, 29.00, "Initial purchase"),
        ("2024-02-20", "DNB.OL", 50, 215.75, 29.00, "Banking sector investment"),
        ("2024-03-10", "MOWI.OL", 75, 180.25, 29.00, "Seafood industry exposure"),
        ("2024-04-05", "TEL.OL", 40, 125.50, 29.00, "Telecom dividend play"),
        ("2024-05-15", "YAR.OL", 30, 420.00, 29.00, "Fertilizer sector"),
        ("2024-06-01", "EQNR.OL", 50, 365.00, 29.00, "Adding to position"),
    ]
    
    cur = conn.cursor()
    for date, ticker, quantity, price, fee, notes in sample_transactions:
        cur.execute("""
            INSERT INTO transactions (date, ticker, quantity, price, fee, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (date, ticker, quantity, price, fee, notes))
    
    # Add sample dividends
    sample_dividends = [
        ("2024-05-20", "EQNR.OL", 315.00, 100, 3.15, "Q1 2024 dividend"),
        ("2024-06-15", "DNB.OL", 175.00, 50, 3.50, "Semi-annual dividend"),
        ("2024-07-10", "MOWI.OL", 97.50, 75, 1.30, "Q2 2024 dividend"),
    ]
    
    for date, ticker, amount, shares, per_share, notes in sample_dividends:
        cur.execute("""
            INSERT INTO received_dividends (date, ticker, amount, shares_held, per_share, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (date, ticker, amount, shares, per_share, notes))
    
    conn.commit()
    print("✅ Added sample transactions and dividends")

def main():
    """Main initialization function"""
    print("🚀 Initializing Oslo Børs Portfolio Tracker Database")
    print("=" * 50)
    
    # Connect to database
    conn = sqlite3.connect(DB_NAME)
    
    try:
        # Create tables
        create_tables(conn)
        
        # Check if tickers table is empty
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM tickers")
        ticker_count = cur.fetchone()[0]
        
        if ticker_count == 0:
            # Try to load from CSV first
            if not load_sample_tickers(conn):
                # If no CSV, load default tickers
                load_default_oslo_tickers(conn)
        else:
            print(f"ℹ️  Tickers table already contains {ticker_count} entries")
        
        # Check if we should add sample data
        cur.execute("SELECT COUNT(*) FROM transactions")
        tx_count = cur.fetchone()[0]
        
        if tx_count == 0 and len(sys.argv) > 1 and sys.argv[1] == '--with-samples':
            add_sample_transactions(conn)
        elif tx_count > 0:
            print(f"ℹ️  Transactions table already contains {tx_count} entries")
        
        print("\n✅ Database initialization complete!")
        print(f"📁 Database file: {DB_NAME}")
        
        # Show summary
        print("\n📊 Database Summary:")
        tables = ['tickers', 'transactions', 'received_dividends', 'market_cache', 'historical_dividends']
        for table in tables:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            count = cur.fetchone()[0]
            print(f"  - {table}: {count} records")
        
    except Exception as e:
        print(f"❌ Error during initialization: {e}")
        return 1
    finally:
        conn.close()
    
    return 0

if __name__ == "__main__":
    exit(main())
