#!/bin/bash

# Oslo Børs Portfolio Tracker - Startup Script

echo "🚀 Starting Oslo Børs Portfolio Tracker..."
echo "=========================================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install/update requirements
echo "📥 Installing requirements..."
pip install -r requirements.txt --quiet

# Check if database exists
if [ ! -f "data.db" ]; then
    echo "🗄️ Initializing database..."
    python db_init.py
    
    # Ask if user wants sample data
    read -p "Do you want to add sample transactions? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        python db_init.py --with-samples
    fi
fi

# Start the application
echo ""
echo "✅ Starting Streamlit application..."
echo "📱 Open your browser at: http://localhost:8501"
echo "Press Ctrl+C to stop the application"
echo "=========================================="

streamlit run app.py
