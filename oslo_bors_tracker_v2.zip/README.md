# 📈 Oslo Børs Portfolio & Dividend Tracker

[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new?hide_repo_select=true&ref=main)

En omfattende Streamlit-applikasjon for å spore din aksjeportefølje på Oslo Børs med sanntids markedsdata fra Yahoo Finance.

## 🚀 Rask Start med GitHub Codespaces (Anbefalt!)

### Start på 30 sekunder:
1. **Klikk på den grønne "Code"-knappen** i GitHub-repositoriet
2. **Velg "Codespaces"-fanen**
3. **Klikk "Create codespace on main"**
4. **Vent ca. 1-2 minutter** mens miljøet setter seg opp automatisk
5. **Kjør i terminalen:** `streamlit run app.py`
6. **Appen åpnes automatisk** i en ny fane!

### Fordeler med Codespaces:
- ✅ **Ingen lokal installasjon nødvendig**
- ✅ **Alt settes opp automatisk**
- ✅ **Fungerer fra hvilken som helst enhet**
- ✅ **Database med eksempeldata inkludert**
- ✅ **VS Code i nettleseren**

## ✨ Funksjoner

### 📊 Dashboard
- **Porteføljeoversikt**: Se total verdi, gevinst/tap og ytelse
- **Visuell fremstilling**: Interaktive diagrammer for portefølje- og sektorfordeling
- **Sanntidsdata**: Oppdaterte kurser fra Yahoo Finance
- **Holdings-oversikt**: Detaljert tabell med alle dine posisjoner

### 🏢 Selskapsdetaljer (NY!)
- **Detaljert selskapsvisning**: Se all informasjon om ett selskap
- **Historiske utbytter**: Komplett utbyttehistorikk med grafer
- **Din posisjon**: Se dine transaksjoner og gevinst/tap per selskap
- **Utbyttestatistikk**: CAGR, gjennomsnitt, trend-analyse
- **Interaktive grafer**: Visualisering av utbyttehistorikk over tid
- **Last ned data**: Eksporter utbyttehistorikk som CSV

### 💼 Transaksjoner
- **Kjøp/Salg registrering**: Enkel registrering av alle handler
- **Kurtasjesporing**: Hold oversikt over transaksjonskostnader
- **Historikk**: Full oversikt over alle tidligere transaksjoner
- **Notater**: Legg til notater til hver transaksjon

### 💰 Utbyttehåndtering
- **Registrer mottatte utbytter**: Spor alle utbyttebetalinger
- **Historiske utbytter**: Automatisk henting fra Yahoo Finance
- **Utbytteanalyse**: Se utbytteavkastning og historikk per aksje
- **Automatisk beregning**: Beregner utbytte per aksje basert på beholdning

### 📈 Analyse
- **Utbytteavkastning**: Rangering av aksjer etter yield
- **Sektoranalyse**: Se hvordan porteføljen er fordelt
- **Ytelsesmålinger**: Detaljert gevinst/tap-analyse
- **Topp 10 lister**: Visualisering av beste utbytteaksjer

### 🔄 Markedsdata
- **50+ Oslo Børs-aksjer**: Forhåndslastet med de mest handlede aksjene
- **Automatisk oppdatering**: Ett-klikks oppdatering av alle kurser
- **Utbyttehistorikk**: Henter historiske utbytter automatisk
- **Cache-system**: Effektiv lagring av markedsdata

## 🚀 Installasjon

### Forutsetninger
- Python 3.8 eller nyere
- pip (Python package manager)

### Steg 1: Klon eller last ned prosjektet
```bash
git clone <repository-url>
cd oslo-bors-tracker
```

### Steg 2: Installer avhengigheter
```bash
pip install -r requirements.txt
```

### Steg 3: Initialiser databasen
```bash
python db_init.py
```

For å legge til eksempeldata:
```bash
python db_init.py --with-samples
```

### Steg 4: Start applikasjonen
```bash
streamlit run app.py
```

Applikasjonen vil åpne i din nettleser på `http://localhost:8501`

## 📝 Brukerveiledning

### Første gangs oppsett
1. Start applikasjonen med `streamlit run app.py`
2. Klikk på **"🔄 Last inn Oslo Børs aksjer"** i sidemenyen
3. Klikk på **"📊 Oppdater alle markedsdata"** for å hente kurser

### Registrere transaksjoner
1. Gå til **"💼 Transaksjoner"**-fanen
2. Velg ticker fra dropdown eller skriv inn manuelt
3. Velg dato og type (Kjøp/Salg)
4. Legg inn antall aksjer og pris
5. Klikk **"Registrer transaksjon"**

### Registrere utbytter
1. Gå til **"💰 Utbytter"**-fanen
2. Velg ticker som har betalt utbytte
3. Legg inn dato og beløp mottatt
4. Klikk **"Registrer utbytte"**

### Se selskapsdetaljer (NY!)
1. Gå til **"🏢 Selskapsdetaljer"**-fanen
2. Velg selskap fra dropdown-menyen
3. Se detaljert informasjon:
   - Nøkkeltall og markedsdata
   - Din posisjon og gevinst/tap
   - Komplett utbyttehistorikk med grafer
   - Årlig utbyttevekst (CAGR)
4. Last ned utbyttehistorikk som CSV
5. Oppdater data for enkeltselskap

### Oppdatere markedsdata
- Klikk **"📊 Oppdater alle markedsdata"** i sidemenyen
- Dette henter nye kurser og utbyttehistorikk fra Yahoo Finance

## 📊 Database-struktur

Applikasjonen bruker SQLite med følgende tabeller:

- **tickers**: Aksjeinformasjon (ticker, navn, sektor, industri)
- **transactions**: Kjøp/salg-transaksjoner
- **received_dividends**: Mottatte utbytter
- **market_cache**: Cached markedsdata
- **historical_dividends**: Historiske utbytter fra Yahoo Finance

## 🔧 Avanserte funksjoner

### Legge til egne aksjer
1. Bruk **"➕ Legg til ticker manuelt"** i sidemenyen
2. Skriv inn ticker-kode (f.eks. "AKER.OL")
3. Klikk **"Legg til"**

### Eksportere data
- Gå til **"⚙️ Data"**-fanen
- Velg ønsket tabell
- Klikk **"Last ned som CSV"**

### Yahoo Finance ticker-format
Oslo Børs-aksjer bruker formatet: `TICKER.OL`
- Eksempel: `EQNR.OL` for Equinor
- Eksempel: `DNB.OL` for DNB Bank

## 🐛 Feilsøking

### Vanlige problemer

**Problem**: "No module named 'streamlit'"
- **Løsning**: Kjør `pip install -r requirements.txt`

**Problem**: Ingen data vises
- **Løsning**: Klikk "Oppdater alle markedsdata" i sidemenyen

**Problem**: Feil ticker-format
- **Løsning**: Bruk formatet TICKER.OL (f.eks. EQNR.OL)

## 📈 Ticker-liste

Applikasjonen inkluderer 50+ Oslo Børs-aksjer, inkludert:

### Energi
- EQNR.OL (Equinor)
- AKRBP.OL (Aker BP)
- SUBC.OL (Subsea 7)

### Finans
- DNB.OL (DNB Bank)
- GJFS.OL (Gjensidige)
- STB.OL (Storebrand)

### Sjømat
- MOWI.OL (Mowi)
- SALM.OL (SalMar)
- BAKKA.OL (Bakkafrost)

### Industri
- KOG.OL (Kongsberg Gruppen)
- TOM.OL (Tomra Systems)
- YAR.OL (Yara International)

### Teknologi
- NOD.OL (Nordic Semiconductor)
- KAHOT.OL (Kahoot!)
- CRAYN.OL (Crayon)

Se `oslo_bors_tickers.csv` for komplett liste.

## 🤝 Bidrag

Bidrag er velkomne! Vennligst opprett en issue eller pull request.

## 📄 Lisens

Dette prosjektet er åpen kildekode og tilgjengelig under MIT-lisensen.

## ⚠️ Ansvarsfraskrivelse

Denne applikasjonen er kun for informasjonsformål og skal ikke betraktes som investeringsrådgivning. Gjør alltid din egen research før du tar investeringsbeslutninger.

## 🙏 Krediteringer

- Markedsdata fra [Yahoo Finance](https://finance.yahoo.com) via [yfinance](https://github.com/ranaroussi/yfinance)
- UI bygget med [Streamlit](https://streamlit.io)
- Visualiseringer med [Plotly](https://plotly.com)

---

**Utviklet for Oslo Børs-investorer 🇳🇴**
